#include <iostream>
#include "tools.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;
using std::vector;

Tools::Tools() {}

Tools::~Tools() {}

VectorXd Tools::CalculateRMSE(const vector<VectorXd> &estimations,
                              const vector<VectorXd> &ground_truth) {
  /**
  TODO:
    * Calculate the RMSE here.
  */
	// initialize the rmse vector. 20181107
	VectorXd rmse(4);
	rmse << 0, 0, 0, 0;

	// dimensions' consistency judgement
	if ((estimations.size() == 0) || estimations.size() != ground_truth.size())
	{
		std::cout << "There is something wrong with the their dimensions!!" << std::endl;
		return rmse;
	};

	// initialize the residual vector.20181107
	VectorXd residual(4);
	residual << 0, 0, 0, 0;

	// calculate residual
	for (int i = 0; i < estimations.size(); i++)
	{
		residual = estimations[i] - ground_truth[i];
		residual = residual.array()*residual.array();
		rmse += residual;
	}

	// calculate the mean
	VectorXd mean;
	mean = rmse / estimations.size();

	//calculate the squared root
	VectorXd sqrt_root;
	sqrt_root = mean.array().sqrt();
	rmse = sqrt_root;
	
	// return the rmse
	return rmse;
}

MatrixXd Tools::CalculateJacobian(const VectorXd& x_state) {
  /**
  TODO:
    * Calculate a Jacobian here.
  */

	MatrixXd Hj(3, 4); // initialize
	Hj << 0, 0, 0, 0,
		0, 0, 0, 0,
		0, 0, 0, 0;

	//recover state parameters
	float px = x_state(0);
	float py = x_state(1);
	float vx = x_state(2);
	float vy = x_state(3);

	//TODO: YOUR CODE HERE 
	float c1 = px * px + py * py;
	float c2 = sqrt(c1);
	float c3 = c1 * c2;

	//check division by zero
	if (c1 < 0.000001)
	{
		cout << "check division by zero failed!!" << endl;
		return Hj;
	};

	//compute the Jacobian matrix
	Hj(0, 0) = px / c2;
	Hj(0, 1) = py / c2;
	Hj(1, 0) = -py / c1;
	Hj(1, 1) = px / c1;
	Hj(2, 0) = py * (vx*py - vy * px) / c3;
	Hj(2, 1) = px * (vy*px - vx * py) / c3;
	Hj(2, 2) = px / c2;
	Hj(2, 3) = py / c2;

	return Hj;

}
