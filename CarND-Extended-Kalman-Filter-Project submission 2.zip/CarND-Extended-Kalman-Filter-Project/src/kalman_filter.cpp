#define _USE_MATH_DEFINES
#include <cmath>
#include "kalman_filter.h"

using Eigen::MatrixXd;
using Eigen::VectorXd;

// Please note that the Eigen library does not initialize 
// VectorXd or MatrixXd objects with zeros upon creation.

KalmanFilter::KalmanFilter() {}

KalmanFilter::~KalmanFilter() {}

void KalmanFilter::Init(VectorXd &x_in, MatrixXd &P_in, MatrixXd &F_in,
                        MatrixXd &H_in, MatrixXd &R_in, MatrixXd &Q_in) {
  x_ = x_in;
  P_ = P_in;
  F_ = F_in;
  H_ = H_in;
  R_ = R_in;
  Q_ = Q_in;
}

void KalmanFilter::Predict() {
  /**
  TODO:
    * predict the state
  */

	x_ = F_ * x_; // +u_;
	P_ = F_ * P_*F_.transpose() + Q_;

	// return NULL;

}

void KalmanFilter::Update(const VectorXd &z) {
  /**
  TODO:
    * update the state by using Kalman Filter equations
  */

	//VectorXd K_ = VectorXd(2);
	//MatrixXd y_ = MatrixXd(1, 1);
	//MatrixXd S_ = MatrixXd(1, 1);

	MatrixXd K_ ;
	VectorXd y_ ;
	MatrixXd S_ ;


	long x_size = x_.size();
	MatrixXd I_ = MatrixXd::Identity(x_size, x_size);

	y_ = z - H_ * x_;
	S_ = H_ * P_*H_.transpose() + R_;
	K_ = P_ * H_.transpose()*S_.inverse();
	x_ = x_ + K_ * y_;
	P_ = (I_ - K_ * H_)*P_;
	
	// return NULL;

}

VectorXd KalmanFilter:: coordinate_transfer(const VectorXd &x_state)
{
	float px, py, vx, vy;
	float rho, phi, rho_dot;

	px = x_state[0];
	py = x_state[1];
	vx = x_state[2];
	vy = x_state[3];

	rho = sqrt(px*px + py*py);
	phi = atan2(py, px);  // returns values between -pi and pi
	rho_dot = (px * vx + py * vy) / rho;

	// avoiding division by 0 in computing rho_dot
	if (rho < 0.000001) 
	{
		rho = 0.000001;
	}

	VectorXd Coordinate(3);
	Coordinate(0) = rho;
	Coordinate(1) = phi;
	Coordinate(2) = rho_dot;

	return Coordinate;
}


void KalmanFilter::UpdateEKF(const VectorXd &z) {
  /**
  TODO:
    * update the state by using Extended Kalman Filter equations
  */

  // convert radar measurements from cartesian coordinates (x, y, vx, vy) to polar (rho, phi, rho_dot).
	VectorXd z_pred = coordinate_transfer(x_);

	VectorXd y = z - z_pred;

	// normalize the angle between -pi to pi
	while (y(1) > M_PI) {
		y(1) -= (2 * M_PI); // math.pi
	}

	while (y(1) < -M_PI) {
		y(1) += (2 * M_PI);
	}

	// following is exact the same as in the function of KalmanFilter::Update()
	MatrixXd Ht = H_.transpose();
	MatrixXd PHt = P_ * Ht;
	MatrixXd S = H_ * PHt + R_;
	MatrixXd Si = S.inverse();
	MatrixXd K = PHt * Si;

	//new estimate
	x_ = x_ + (K * y);
	long x_size = x_.size();
	MatrixXd I = MatrixXd::Identity(x_size, x_size);
	P_ = (I - K * H_) * P_;

}
